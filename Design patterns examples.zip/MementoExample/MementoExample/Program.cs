﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MementoExample.Memento;

namespace MementoExample
{
    public class Program
    {
        public static void Main(string[] args)
        {
            MementoCaretaker caretaker = new MementoCaretaker();
            TextArea textArea = new TextArea("AAAAAAAAAAAAAAAAAA");

            Console.WriteLine(textArea);
            caretaker.SaveTextAreaState(textArea.CreateMemento());

            textArea.BackgroundColor = "yellow";
            textArea.AppendText("_BBBBBBBBBBBBBBBB");
            Console.WriteLine(textArea);
            caretaker.SaveTextAreaState(textArea.CreateMemento());

            textArea.FontSize = 13;
            textArea.AppendText("_CCCCCCCCCCCCCCC");
            Console.WriteLine(textArea);

            textArea.SetMemento(caretaker.RetreiveTextAreaState());
            Console.WriteLine(textArea);

            textArea.SetMemento(caretaker.RetreiveTextAreaState());
            Console.WriteLine(textArea);

            textArea.SetMemento(caretaker.RetreiveTextAreaState());
            Console.WriteLine(textArea);


        }
    }
}

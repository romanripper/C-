﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MementoExample.Memento
{
    public class MementoCaretaker
    {
        private Stack<TextAreaMemento> mementos = new Stack<TextAreaMemento>();

        public void SaveTextAreaState(TextAreaMemento memento)
        {
            Console.WriteLine("Saving state...");
            mementos.Push(memento);
        }

        public TextAreaMemento RetreiveTextAreaState()
        {
            switch (mementos.Count)
            {
                case 0:
                    Console.WriteLine("Sorry there are no saved states yet\n");
                    return null;
                default:
                    Console.WriteLine("Retreiving state...");
                    return mementos.Pop();
            }

        }
    }
}

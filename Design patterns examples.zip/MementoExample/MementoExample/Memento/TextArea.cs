﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MementoExample.Memento
{
    public class TextArea
    {
        public string Text { get; set; }
        public string Font { get; set; }
        public int FontSize { get; set; }
        public string BackgroundColor { get; set; }

        public TextArea(string text)
        {
            Text = text;
            Font = "Arial";
            FontSize = 12;
            BackgroundColor = "white";
        }

        public void SetMemento(TextAreaMemento memento)
        {
            if (memento != null)
            {
                Text = memento.Text;
                Font = memento.Font;
                FontSize = memento.FontSize;
                BackgroundColor = memento.BackgroundColor;
            }
        }
        public TextAreaMemento CreateMemento()
        {
            return new TextAreaMemento(this);
        }

        public void AppendText(string text)
        {
            Text += text;
        }

        public override string ToString()
        {
            return $"Text: {Text}\n" +
                   $"Font: {Font}\n" +
                   $"Font size: {FontSize}\n" +
                   $"Background color: {BackgroundColor}\n";
        }
    }
}

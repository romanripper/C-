﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MementoExample.Memento
{
    public class TextAreaMemento
    {
        public string Text { get; private set; }
        public string Font { get; private set; }
        public int FontSize { get; private set; }
        public string BackgroundColor { get; private set; }

        public TextAreaMemento(TextArea textArea)
        {
            Text = textArea.Text;
            Font = textArea.Font;
            FontSize = textArea.FontSize;
            BackgroundColor = textArea.BackgroundColor;
        }
    }
}

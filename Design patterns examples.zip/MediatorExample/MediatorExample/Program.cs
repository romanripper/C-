﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MediatorExample.Mediator;

namespace MediatorExample
{
    public class Program
    {
        public static void Main(string[] args)
        {
            TaxiDispatcherCenter taxiDispatcherCenter = new TaxiDispatcherCenter();
            TaxiDriver taxiDriver1 = new TaxiDriver("Tom", "Angelo", "Blue Ford Mustang", taxiDispatcherCenter);
            Client client1 = new Client("Ennio", "Salieri", taxiDispatcherCenter);
            TaxiDriver taxiDriver2 = new TaxiDriver("Meyer", "Lansky", "Blue Ford Mustang", taxiDispatcherCenter);
            Client client2 = new Client("Lucky", "Luciano", taxiDispatcherCenter);
            
            taxiDispatcherCenter.AddOrder(taxiDriver1, client1);
            taxiDispatcherCenter.AddOrder(taxiDriver2, client2);

            taxiDriver1.SendMessage("Car is waiting near your house");
            client1.SendMessage("Coming");
            Console.WriteLine();
            taxiDriver2.SendMessage("Will be in 10 minutes");
            client2.SendMessage("Ok. Waiting");
            
        }
    }
}

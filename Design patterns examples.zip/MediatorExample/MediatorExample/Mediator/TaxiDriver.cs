﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediatorExample.Mediator
{
    public class TaxiDriver : Person
    {
        public string Name { get; set; }
        public string Surname { get; set; }
        public string CarInformation { get; set; }

        public TaxiDriver(string name, string surname, string carInformation, TaxiDispatcherCenter dispatcher)
        {
            Name = name;
            Surname = surname;
            CarInformation = carInformation;
            Dispatcher = dispatcher;
        }

        public override void SendMessage(string message)
        {
            Console.WriteLine($"Message to client from taxi driver {this.Surname} - Sending...");
            Dispatcher.NotifyReceiver(message, this);
        }

        public override void ReceiveMessage(string message)
        {
            Console.WriteLine($"Message from client: {message} - Received");
        }

        public override bool Equals(object obj)
        {
            var driver = obj as TaxiDriver;
            return driver != null &&
                   Name == driver.Name &&
                   Surname == driver.Surname &&
                   CarInformation == driver.CarInformation;
        }

        public override int GetHashCode()
        {
            var hashCode = 1871454301;
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Name);
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Surname);
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(CarInformation);
            return hashCode;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediatorExample.Mediator
{
    public class TaxiDispatcherCenter
    {
        private IDictionary<TaxiDriver, Client> Orders = new Dictionary<TaxiDriver, Client>();
        public void NotifyReceiver(string message, Person sender)
        {
            foreach (KeyValuePair<TaxiDriver, Client> item in Orders)
            {
                if (sender.Equals(item.Key))
                {
                    item.Value.ReceiveMessage(message);
                    return;
                }
                else if (sender.Equals(item.Value))
                {
                    item.Key.ReceiveMessage(message);
                    return;
                }
            }
        }
        public void AddOrder(TaxiDriver taxiDriver, Client client)
        {
            Orders.Add(new KeyValuePair<TaxiDriver, Client>(taxiDriver, client));
        }

    }
}

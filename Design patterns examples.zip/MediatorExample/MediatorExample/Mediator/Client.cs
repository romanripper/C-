﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediatorExample.Mediator
{
    public class Client : Person
    {
        public string Name { get;}
        public string Surname { get;}

        public Client(string name, string surname, TaxiDispatcherCenter dispatcher)
        {
            Name = name;
            Surname = surname;
            Dispatcher = dispatcher;
        }
        public override void SendMessage(string message)
        {
            Console.WriteLine($"Message to taxi driver from {this.Surname} - Sending...");
            Dispatcher.NotifyReceiver(message, this);
        }

        public override void ReceiveMessage(string message)
        {
            Console.WriteLine($"Message from taxi driver: {message} - Received");
        }

        public override bool Equals(object obj)
        {
            var client = obj as Client;
            return client != null &&
                   Name == client.Name &&
                   Surname == client.Surname;
        }

        public override int GetHashCode()
        {
            var hashCode = 305228700;
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Name);
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Surname);
            return hashCode;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ObjectPoolExample.ObjectPool;

namespace ObjectPoolExample
{
    public class Program
    {
        public static void Main(string[] args)
        {

            ParkingLot parkingLot = ParkingLot.GetInstance(2);
            Client client1 = new Client(1, parkingLot);
            Client client2 = new Client(2, parkingLot);
            Client client3 = new Client(3, parkingLot);

            client1.OccupyParkingPlace();
            client2.OccupyParkingPlace();
            client3.OccupyParkingPlace();
            client1.ReleaseParkingPlace();
            client3.OccupyParkingPlace();
        }
    }
}

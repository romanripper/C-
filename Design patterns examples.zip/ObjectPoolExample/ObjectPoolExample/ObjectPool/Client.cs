﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectPoolExample.ObjectPool
{
    public class Client
    {
        public int Id { get; set; }
        private ParkingLot parkingLot;
        public ParkingPlace Place { get; private set; }

        public Client(int id, ParkingLot parkingLot)
        {
            Id = id;
            this.parkingLot = parkingLot;
        }

        public void OccupyParkingPlace()
        {
            try
            {
                Place = parkingLot.AcquireParkingPlace();
                Console.WriteLine($"{this} occupied {Place}");
            }
            catch (Exception e)
            {
                Console.WriteLine($"{this} didn't occupy parking place because there is {e.Message}");
            }
        }

        public void ReleaseParkingPlace()
        {
            parkingLot.ReleaseParkingPlace(Place);
            Console.WriteLine($"{this} released {Place}");
            Place = null;
        }

        public override string ToString()
        {
            return $"Client{Id}";
        }


    }
}

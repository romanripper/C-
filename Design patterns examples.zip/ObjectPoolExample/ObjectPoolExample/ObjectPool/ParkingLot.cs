﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectPoolExample.ObjectPool
{
    public class ParkingLot
    {
        private static ParkingLot instance;
        private IList<ParkingPlace> availablePlaces;
        private IList<ParkingPlace> occupiedPlaces;
        public int maxParkingPlaces { get; private set; }
        private ParkingLot(int places)
        {
            availablePlaces = new List<ParkingPlace>();
            occupiedPlaces = new List<ParkingPlace>();
            maxParkingPlaces = places;
        }

        public static ParkingLot GetInstance(int places)
        {
            if (instance == null)
                instance = new ParkingLot(places);
            return instance;
        }

        public void SetMaxParkingPlaces(int places)
        {
            maxParkingPlaces = places;
        }
        public ParkingPlace AcquireParkingPlace()
        {
            if (availablePlaces.Count == 0 && CountPlaces() < maxParkingPlaces)
                availablePlaces.Add(new ParkingPlace(CountPlaces() + 1));
            if (availablePlaces.Count > 0)
            {
                var place = availablePlaces.Last();
                AddToListAndRemoveFromList(availablePlaces, occupiedPlaces, place);
                return place;
            }
            else
                throw new Exception("no available places");
        }
        public void ReleaseParkingPlace(ParkingPlace place)
        {
            AddToListAndRemoveFromList(occupiedPlaces, availablePlaces, place);
        }
        private int CountPlaces()
        {
            return availablePlaces.Count + occupiedPlaces.Count;
        }
        private void AddToListAndRemoveFromList(IList<ParkingPlace> listFrom, IList<ParkingPlace> listTo, ParkingPlace place)
        {
            listFrom.Remove(place);
            listTo.Add(place);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChainOfResponsibilityExample.Calc
{
    public class AddOperation : Operation
    {
        public override int HandleRequest(Request request)
        {
            if (request.Operation.Equals("+"))
            {
                return request.FirstNumber + request.SecondNumber;
            }
            else
            {
                throw new Exception("Not implemented operation yet");
            }
        }
    }
}

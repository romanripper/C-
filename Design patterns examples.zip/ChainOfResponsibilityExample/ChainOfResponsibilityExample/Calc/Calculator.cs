﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChainOfResponsibilityExample.Calc
{
    class Calculator
    {
        private Operation chain;
        public void IntializeChain()
        {
            Operation multiplayOperation = new MultiplyOperation();
            Operation subtractOperation = new SubtractOperation();
            chain = new DivideOperation(); ;
            chain.CurrOperation = multiplayOperation;
            multiplayOperation.CurrOperation = subtractOperation;
            subtractOperation.CurrOperation = new AddOperation();
        }
        public int DoOperation(Request request)
        {
            return chain.HandleRequest(request);
        }
    }
}

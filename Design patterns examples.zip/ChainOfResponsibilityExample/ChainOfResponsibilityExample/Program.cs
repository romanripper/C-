﻿using ChainOfResponsibilityExample.Calc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChainOfResponsibilityExample
{
    class Program
    {
        static void Main(string[] args)
        {
            Calculator calculator = new Calculator();
            calculator.IntializeChain();

            Request request = new Request(12, 3, "s");
            try
            {
                Console.WriteLine(calculator.DoOperation(request));
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}

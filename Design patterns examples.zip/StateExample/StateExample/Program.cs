﻿using StateExample.State;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StateExample
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Person perfectPerson = new Person("John", "Perfect");

            perfectPerson.DrinkSmallBeer();
            perfectPerson.Drive();
            Console.WriteLine();

            perfectPerson.DrinkGlassWine();
            perfectPerson.Drive();
            Console.WriteLine();

            perfectPerson.DrinkMuchVodka();
            perfectPerson.Drive();
            Console.WriteLine();

            perfectPerson.Sleep();
            perfectPerson.Drive();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StateExample.State
{
    public class Person
    {
        public string Name { get; set; }
        public string Surname { get; set; }
        public State CurrentState { get; set; }
        public double BloodAlcoholContent { get; private set; }

        public Person(string name, string surname)
        {
            Name = name;
            Surname = surname;
            CurrentState = new Sober();
            BloodAlcoholContent = 0;
        }
        
        #region Transitions between states
        public void DrinkSmallBeer()
        {
            BloodAlcoholContent += 0.01;
            Console.WriteLine("Drinking small beer");
            UpdateState();
        }
        public void DrinkGlassWine()
        {
            BloodAlcoholContent += 0.04;
            Console.WriteLine("Drinking a glass of wine");
            UpdateState();
        }
        public void DrinkMuchVodka()
        {
            BloodAlcoholContent += 0.35;
            Console.WriteLine("Drinking a lot of vodka");
            UpdateState();
        }
        public void Sleep()
        {
            BloodAlcoholContent = 0;
            Console.WriteLine("Sleeping 3 days");
            UpdateState();
        }
        private void UpdateState()
        {
            if (BloodAlcoholContent < 0.02)
                CurrentState = new Sober();
            else if (BloodAlcoholContent >= 0.02 && BloodAlcoholContent < 0.3)
                CurrentState = new Drunk();
            else
                CurrentState = new DeadlyDrunk();
        }
        #endregion

        public void Drive()
        {
            CurrentState.Drive();
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StateExample.State
{
    public class DeadlyDrunk : State
    {
        public void Drive()
        {
            Console.WriteLine($"... (felt into coma)");
        }
    }
}
